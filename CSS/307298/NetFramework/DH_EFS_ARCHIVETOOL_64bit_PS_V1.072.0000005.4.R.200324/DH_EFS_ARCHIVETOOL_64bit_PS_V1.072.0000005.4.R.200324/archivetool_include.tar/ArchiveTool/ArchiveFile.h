//
//  "$Id$"
//
//  Copyright ( c )2015-2020, ZheJiang Dahua Technology Stock CO.LTD.
//  All Rights Reserved.
//
//	Description:
//	Revisions:		Year-Month-Day  SVN-Author  Modification
//

#ifndef __INCLUDE_DAHUA_ARCHIVE_FILE_H__
#define __INCLUDE_DAHUA_ARCHIVE_FILE_H__

#include "EFSClient/Defs.h"
#include "EFSClient/EFileSystem.h"
#include <string>
#include <vector>

// WIN32 Dynamic Link Library
#ifdef _MSC_VER

#ifdef ARCHIVE_DLL_BUILD
#define  EFS_ARCHIVE_API _declspec(dllexport)
#elif defined ARCHIVE_DLL_USE
#define  EFS_ARCHIVE_API _declspec(dllimport)
#else
#define EFS_ARCHIVE_API
#endif

#else

#define EFS_ARCHIVE_API

#endif

namespace Dahua{
namespace EFS{


class CArchiveFileWriter;
class CArchiveManagerImpl;
class EFS_ARCHIVE_API CArchiveManager{
public:

	static CArchiveManager& instance();
	
	/**
	 * 配置本地存储
	 * @param enable [IN] true使能本地存储，false不使能本地存储
	 * @param mode [IN] 获取本地存储路径的模式，可选：0-部署在datanode上从DN服务上获取;1-从配置中获取;2-先尝试0再尝试1
	 * @param paths [IN] 用于本地存储的路径，可为空
	 * @return true设置成功，false设置失败
	 * @note 必须在init()接口前调用
	 * @note 当enable为false时，后两个参数不生效，但值必须正确
	 * @warn 当mode为2，如果本地存储路径初始化失败，init()仍会成功，但本地存储无法使用
	 */
	bool configLocalStorage( bool enable, int32_t mode, std::vector<std::string>& paths );
	
	/**
	 * init 
	 * @Brief 根据指定的配置文件，初始化配置，日志，本地存储/恢复等功能
	 * @param cfgPath [IN] 配置文件路径
	 * @return bool，成功true，失败false
	 * */
	bool init( std::string cfgPath );

	/**
	 * CArchiveFileWriter创建函数
	 * @param  ptr		  [IN] CEFileSystem实例指针
	 * @param  regionname [IN] 子域名
	 * return	成功返回CArchiveFileWriter实例指针，失败返回NULL
	 */
	CArchiveFileWriter* createFileWriter( CEFileSystem* ptr,
			const std::string& regionname = "" );

	/**
	 * CArchiveFileWriter删除函数
	 * @param  ptr		  [IN] CArchiveFileWriter实例指针
	 * return	成功返回true，失败返回false
	 */
	bool releaseFileWriter( CArchiveFileWriter* ptr );

	/**
	 * 同步释放打包工具所占资源，刷写缓存至存储系统中,析构前需要主动调用release
	 * return NULL
	 */
	void release();

	// 获取指定EFS的状态
	bool getEfsState( CEFileSystem* ptr,  EFSState &state );
	
private:
	CArchiveManager();
	~CArchiveManager();

private:
	class CArchiveManagerImpl* m_impl;
};

typedef enum{
	fileWriterSizeLimited = -1,	//小文件达到上限
	fileWriterReadonly = -2,	//当前不可写
	fileWriterParamError = -3,	//参数错误
}FileWriterErrCode;



class CArchiveFileWriterImpl;
class CArchiveManagerImpl;
class EFS_ARCHIVE_API CArchiveFileWriter{
public:
	/**
	 * 初始化打包工具
	 * @param  n		  [IN] 冗余参数，和参数m一起表示n+m，其中n表示n个数据分片，m表示m个数据分片，
	 *		   n+m表示n个数据分片形成m个冗余，支持m个错误发生而不影响数据的完整性
	 * @param  m		  [IN] 冗余参数，注意目前只支持3+1和7+2
	 * @param  bucketname [IN] bucket名字，打包大文件存储到该bucket中
	 * @return ture成功
	 *		   false失败
	 */
	bool init( const uint16_t n, const uint16_t m, const std::string& bucketname );

	/**
	 * 设置打包文件存储的Bucket
	 * @param  bucketname [IN] bucket名字，打包大文件存储到该bucket中
	 * @return ture成功
	 *		   false失败
	 */
	bool setBucket( const std::string& bucketname );

	/**
	 * 获取打包大文件存储Bucket名称
	 * @param  bucketname [OUT] bucket名字
	 * @return ture成功
	 */
	bool getBucket( std::string& bucketname ) const;

	/**
	 * 设置打包工具缓存小文件数量(接口已废弃)
	 * @describe 设置打包工具缓存小文件数量，取值范围为[32,1024]
	 * @param  number [IN] 缓存小文件个数
	 * @return ture成功
	 *		   false失败
	 */
	bool setMaxCachedFilesNumber( const uint32_t number );

	/**
	 * 获取打包工具缓存小文件数量(接口已废弃)
	 * @describe 打包工具缓存小文件数量
	 * @return 最大缓存小文件数量
	 */
	uint32_t getMaxCachedFilesNumber() const;

	/**
	 * 获取打包工具当前缓存小文件数量(接口已废弃)
	 * @describe 打包工具当前缓存小文件数量
	 * @return 当前缓存小文件数量
	 */
	uint32_t getCurrentCachedFilesNumber() const;

	/**
	 * 获取打包大文件存储的域
	 * @describe 通过子域名，获取打包大文件存储的域
	 * @param  regionname [OUT] 子域名
	 * @return ture成功
	 */
	bool getRegionName( std::string& regionname ) const;

	/**
	 * 打开小文件
	 * @describe 打开特定后缀的小文件，为写作准备，小文件也可不指定后缀
	 * @param  suffix [IN] 文件名后缀 ,最大支持8字节.
	 *		   超过8字节,suffix存入索引区会被截断,当系统异常需要解析索引来恢复数据时,将导致后缀名不完整
	 * @return ture成功
	 *		   false失败
	 */
	bool open( const std::string& suffix = "" );

	/**
	 * 写入指定长度的小文件数据
	 * @describe 写入指定长度的小文件数据
	 * @param  buffer [IN] 待写入数据
	 * @param  length [IN] 数据长度.
	 *		   注意:在调用close之前,write调用累计传入的buffer长度不得超过1GB,即:打包的单个小文件的长度不得超过1GB
	 * @return 0暂时不可写，待重试
	 *		   大于0实际写入量
	 *		   小于0为失败
	 *		   具体失败原因通过getLastError()获取
	 */
	int write( const char* buffer, const uint32_t length );

	/**
	 * 关闭小文件
	 * @describe 关闭正在写的小文件，并获得写入小文件在云存储系统中的文件名
	 * @param  filename [OUT] 文件名
	 * @return ture成功
	 *		   false失败
	 */
	bool close( std::string& filename );

	/**
	 * 一次性写入小文件
	 * @describe 集成open write close接口的功能,保证这三个接口的原子性
	 * @param suffix [IN] 文件名后缀 ,最大支持8字节.
	 *			超过8字节,suffix存入索引区会被截断,当系统异常需要解析索引来恢复数据时,将导致后缀名不完整
	 * @param  buffer [IN] 待写入数据
	 * @param  length [IN] 数据长度
	 * @param  filename [OUT] 文件名
	 * @return ture成功
	 *		   false失败
	 * @note:必须保证buffer里是一个小文件的全部数据
	 */
	bool writeOnce( const std::string& suffix, const char* buffer, const uint32_t length, std::string& filename );
	
	friend class CArchiveManagerImpl;

private:
	bool release();
	
private:
	CArchiveFileWriter( CArchiveManagerImpl& manager, CEFileSystem* ptr, const std::string& regionname = "" );

	CArchiveFileWriter();
	~CArchiveFileWriter();
	
private:
	CArchiveFileWriterImpl* m_impl;
};

class CArchiveFileReaderImpl;
class EFS_ARCHIVE_API CArchiveFileReader{
public:

	/**
	 * CArchiveFileReader构造函数
	 * @describe CArchiveFileReader构造函数
	 * @param  ptr [IN] CEFileSystem实例指针
	 */
	CArchiveFileReader( CEFileSystem* ptr );
	~CArchiveFileReader();

	/**
	 * 资源释放
	 * @limit 关闭大文件，小文件等类资源，要求用户显示调用efs.close之前，需要主动调用release方法
	 *		  同时，不对EFileSystem对象做释放操作
	 * @return ture成功
	 *		   false失败
	 */
	bool release();
 
	/**
	 * 打开小文件
	 * @describe 打开特定后缀的小文件，为读作准备
	 * @param  filename [IN]	 文件名
	 * @param  length	[OUT] 小文件长度
	 * @return ture成功
	 *		   false失败
	 */
	bool open( const std::string& filename, uint64_t& length );

	/**
	 * 读文件
	 * @describe 读取指定长度的小文件数据
	 * @param  buffer [IN] 读出数据buffer
	 * @param  length [IN] buf长度
	 * @return	   0暂时不可读，待重试
	 *			   大于0实际读出量
	 *			   -1文件异常，需要关闭文件
	 *			   -2读到文件尾
	 *			   失败原因通过getLastError()获取
	 */
	int read( char* buffer, const uint32_t length );

	/**
	 * 关闭正在读的小文件
	 * @describe 关闭正在读的小文件
	 * @return ture成功
	 *		   false失败
	 */
	bool close();

	/**
	 * 一次性读取文件
	 * @describe 集成open,read,close操作，内部保证原子性
	 * @param  filename [IN]     文件名
	 * @param  buffer [INOUT] 读出数据buffer
	 * @param  length [IN] buf长度
	 * @param  timeout [IN] 读取超时时间，单位毫秒
	 *					-1，表示直到读取成功才返回
 	 *					大于等于0，表示超过该时间未读取成功，则返回
	 * @return ture成功
	 * 	   	   false失败
	 */
	bool readOnce( const std::string& filename, char* buffer, const uint32_t length, int32_t timeout );
	
private:
	class CArchiveFileReaderImpl* m_impl;
};


/**
 * 解析文件名
 * @describe 通过打包文件名，提取域名、存储文件名以及数据大小
 * @param  archname   [IN]     打包文件名
 * @param  regionname [OUT] 子域名
 * @param  filename   [OUT] 文件名
 * @param  size       [OUT] 数据大小
 * @return ture成功
 * 	   	   false失败
 */
bool  EFS_ARCHIVE_API getInfos4ArchName( const std::string& archname, std::string& regionname, std::string& filename, uint64_t& size );

}
}
#endif
