//
//  "$Id$"
//
//  Copyright ( c )1992-2013, ZheJiang Dahua Technology Stock CO.LTD.
//  All Rights Reserved.
//
//    Description:
//    Revisions:        Year-Month-Day  SVN-Author  Modification
//

#ifndef __INCLUDE_DAHUA_ARCHIVEADAPTER_H__
#define __INCLUDE_DAHUA_ARCHIVEADAPTER_H__

#include "IntTypes.h"

// WIN32 Dynamic Link Library
#ifdef _MSC_VER

#ifdef ARCHIVE_DLL_BUILD
#define  EFS_ADAPTER_API _declspec(dllexport)
#elif defined ARCHIVE_DLL_USE
#define  EFS_ADAPTER_API _declspec(dllimport)
#else
#define EFS_ADAPTER_API
#endif

#else

#define EFS_ADAPTER_API

#endif

#ifdef __cplusplus
extern "C" {
#endif

/************************************************************************
 ** 常量定义
 ***********************************************************************/
#ifndef EFS_BOOL
#define EFS_BOOL    int32_t
#endif

#ifndef EFS_TRUE
#define EFS_TRUE    1
#endif

#ifndef EFS_FALSE
#define EFS_FALSE   0
#endif

/************************************************************************
 ** 枚举定义
 ***********************************************************************/
typedef enum{
	fileWriterSizeLimited = -1,	//小文件达到上限
	fileWriterReadonly = -2,	//当前不可写
	fileWriterParamError = -3,	//参数错误
}FileWriterErrCode;

#ifndef __INCLUDE_DAHUA_EFS_ADAPTER_H__
//初始化配置信息
typedef struct __EFSConfig
{
    const char* address;                ///<元数据IP地址
    uint32_t    port;                   ///<端口
    const char* userName;               ///<登录名
    const char* password;               ///<登录密码
	char		reserved[120];			///<保留
}EFSConfig;
#endif

/************************************************************************
 ** 结构体定义
 ***********************************************************************/

//ArchiveFileWriter 实例句柄
typedef struct ArchiveWriterHandle{
    uint64_t handle;
}ArchiveWriterHandle;

//ArchiveFileReader 实例句柄
typedef struct ArchiveReaderHandle{
    uint64_t handle;
}ArchiveReaderHandle;

#ifndef __INCLUDE_DAHUA_EFS_ADAPTER_H__
//EFS实例句柄
typedef struct EFSHandle{
    uint64_t handle;
}EFSHandle;
#endif
/************************************************************************
 ** 接口定义
 ***********************************************************************/

/**
 * 判断文件系统是否合法
 * @param  handle 文件系统句柄
 * @return 1      文件系统句柄合法
 *         0      文件系统句柄无效
 */
 EFS_ADAPTER_API EFS_BOOL isEFSHandleValid(EFSHandle handle);

/**
 * 判断ArchiveWriter是否合法
 * @param  handle ArchiveWriter句柄
 * @return 1      文件句柄合法
 *         0      文件句柄无效
 */
EFS_ADAPTER_API EFS_BOOL isArchiveWriterHandleValid(ArchiveWriterHandle handle);

/**
 * 判断ArchiveReader是否合法
 * @param  handle ArchiveReader句柄
 * @return 1      bucket句柄合法
 *         0      bucket句柄无效
 */
EFS_ADAPTER_API EFS_BOOL isArchiveReaderHandleValid(ArchiveReaderHandle handle);

/**
 * 获取错误码
 * @return 错误码，可以通过archiveGetErrorMsg()查看错误原因
 */
EFS_ADAPTER_API int32_t archiveGetLastError();

/**
 * 根据错误码获取错误原因
 * @param  code    错误码
 * @return 字符串  错误原因
 */
EFS_ADAPTER_API const char* archiveGetErrorMsg( int32_t code );

/************************************************************************
 ** EFS接口定义
 ***********************************************************************/

/**
 * 初始化文件系统
 * @param  cfg                 配置文件
 * @return EFSHandler          文件系统句柄
 *         通过isEFSHandleValid来判断句柄是否有效, 失败原因通过efsGetLastError()获取
 *         可能的error code有：
 *         efsOK               成功
 *         efsNetError         网络异常
 *         efsUserInexistent   用户不存在
 *         efsErrorPassword    密码错误
 *         efsMaxClientLimit   达到最大客户端数量
 *         efsParamError       参数错误
 */
EFS_ADAPTER_API EFSHandle efsCreate( EFSConfig* cfg );

/**
 * 设置日志信息
 * @param	logPath             配置文件
 * @param	loglevel			日志级别: 1:fatal 2:error 3:warn 4:info 5:trace 6:debug
 * @return 	1         成功
 * 			0	失败
 */
EFS_ADAPTER_API EFS_BOOL efsSetLog(EFSHandle handle, const char* logPath, int loglevel );

#ifndef __INCLUDE_DAHUA_EFS_ADAPTER_H__
/**
 * 创建一个bucket
 * @param  handle               文件系统句柄
 * @param  name                 Bucket名字，最大长度不超过MAX_BUCKET_NAME_LEN（63）
 *                              不允许以下字符\, *, ?, ", <, >, |, /, ', :
 * @return 	1      				成功
 * 			0					失败
 *                              若失败，通过archiveGetLastError()获取失败原因
 */
EFS_ADAPTER_API EFS_BOOL efsCreateBucket( EFSHandle handle, const char* name );
#endif

/**
 * 删除一个bucket
 * @param  handle             文件系统句柄
 * @param  name bucket        Bucket名字
 * @return 1                  成功
 *         0                  失败，失败原因通过getLastError()获取
 *         可能的error code有：
 *         efsOK              成功
 *         efsFail            失败
 *         efsParamError      参数错误
 */
EFS_ADAPTER_API EFS_BOOL efsRemoveBucket( EFSHandle handle, const char* name );

/**
 * 判断Bucket是否存在
 * @param  handle               文件系统句柄
 * @param  name                 bucket名字
 * @return 1      				成功
 *         0                    失败，通过archiveGetLastError()获取失败原因
 */
EFS_ADAPTER_API EFS_BOOL efsisBucketValid( EFSHandle handle, const char* name );

/**
 * 关闭文件系统并释放句柄
 * @param  handle             文件系统句柄
 * @return 1                  成功
 *         0                  失败，失败原因通过getLastError()获取
 */
EFS_ADAPTER_API EFS_BOOL efsClose( EFSHandle handle );

/************************************************************************
 ** archiveWriter接口定义
 ***********************************************************************/

/**
 * 创建ArchiveWriter
 * @param  handle                 文件系统句柄
 * @param  regionname		               域名，可以为空
 * @return ArchiveWriterHandle   ArchiveWriter句柄
 *         通过isArchiveWriterHandleValid来判断句柄是否有效
 */
EFS_ADAPTER_API ArchiveWriterHandle createArchiveWriter( EFSHandle handle, const char *regionname);

/**
 * 设置系统高级配置
 * @param  handle             ArchiveWriter句柄
 * @param  n               冗余参数，和参数m一起表示n+m，其中n表示n个数据分片，m表示m个数据分片，
 *         n+m表示n个数据分片形成m个冗余，支持m个错误发生而不影响数据的完整性
 * @param  m          冗余参数，注意目前只支持3+1和7+2
 * @param  bucketname  bucket名字，打包大文件存储到该bucket中，bucket需存在
 * @return 1                  成功
 *         0                  失败，失败原因通过getLastError()获取
 */
EFS_ADAPTER_API EFS_BOOL archiveWriterInit( ArchiveWriterHandle handle, const uint16_t n, const uint16_t m,
								const char *bucketname);

/**
* 设置打包文件存储的Bucket
* @param  handle             	ArchiveWriter句柄
* @param  bucketname 	 		bucket名字，打包大文件存储到该bucket中，bucket需存在
* @return 1						成功
* 	   	  0						失败
*/
EFS_ADAPTER_API EFS_BOOL  archiveSetBucket( ArchiveWriterHandle handle, const char* bucketname );

/**
* 获取打包大文件存储Bucket名称
* @param  handle       	ArchiveWriter句柄
* @param  bucketname  	bucket名字，bucket需存在
* @return 1				成功
*		  0				失败
*/
EFS_ADAPTER_API EFS_BOOL  archiveGetBucket( ArchiveWriterHandle handle, char* bucketname );

/**
* 设置打包工具缓存小文件数量
* @describe 设置打包工具缓存小文件数量，取值范围为[32,1024]
* @param  handle  			ArchiveWriter句柄
* @param  number  			缓存小文件个数
* @return 1					成功
*		  0					失败
*/
EFS_ADAPTER_API EFS_BOOL  archiveSetMaxCache( ArchiveWriterHandle handle, const uint32_t number );

/**
* 获取打包工具缓存小文件数量
* @describe 打包工具缓存小文件数量
* @param  handle             ArchiveWriter句柄
* @return 最大缓存小文件数量
*/
EFS_ADAPTER_API uint32_t archiveGetMaxCache(ArchiveWriterHandle handle);

/**
* 获取打包工具当前缓存小文件数量
* @describe 打包工具当前缓存小文件数量
* @param  handle             ArchiveWriter句柄
* @return 当前缓存小文件数量
*/
EFS_ADAPTER_API uint32_t archiveGetCurrentCache(ArchiveWriterHandle handle);

/**
* 获取打包大文件存储的域
* @describe 通过子域名，获取打包大文件存储的域
* @param  handle             ArchiveWriter句柄
* @param  regionname 	 	子域名
* @return 1					成功
*		  0					失败
*/
EFS_ADAPTER_API EFS_BOOL  archiveGetRegionName( ArchiveWriterHandle handle, char* regionname );

/**
* 打开小文件
* @describe 打开特定后缀的小文件，为写作准备，小文件也可不指定后缀
* @param  handle             ArchiveWriter句柄
* @param  suffix 			 文件名后缀 ,最大支持8字节.可以为空
*         超过8字节,suffix存入索引区会被截断,当系统异常需要解析索引来恢复数据时,将导致后缀名不完整
* @return 1					成功
*		  0					失败
*/
EFS_ADAPTER_API EFS_BOOL  archiveWriterOpen( ArchiveWriterHandle handle, const char *suffix );

/**
* 写入指定长度的小文件数据
* @describe 写入指定长度的小文件数据
* @param  handle             ArchiveWriter句柄
* @param  buffer 			 待写入数据，需有效
* @param  length 			 数据长度.
*         注意:在调用close之前,write调用累计传入的buffer长度不得超过1GB,即:打包的单个小文件的长度不得超过1GB
* @return 0暂时不可写，待重试
* 		   大于0实际写入量
* 		   小于0为失败
* 		   具体失败原因通过getLastError()获取
*/
EFS_ADAPTER_API int32_t  archiveWrite( ArchiveWriterHandle handle, const char* buffer, const uint32_t length );

/**
* 关闭小文件
* @describe 关闭正在写的小文件，并获得写入小文件在云存储系统中的文件名
* @param  handle             ArchiveWriter句柄
* @param  filename 			 文件名
* @return 1					成功
*		  0					失败
*/
EFS_ADAPTER_API EFS_BOOL archiveWriterClose( ArchiveWriterHandle handle, char* filename );

/**
* 一次性写入小文件
* @describe 集成了open,write,close操作，内部保证期原子性
* @param  handle             ArchiveWriter句柄
* @param  suffix 			 文件名后缀 ,最大支持8字节.可以为空
*         超过8字节,suffix存入索引区会被截断,当系统异常需要解析索引来恢复数据时,将导致后缀名不完整
* @param  buffer 			 待写入数据，需有效
* @param  length 			 数据长度.
* @param  filename 			 文件名
* @return 1					成功
*		  0					失败
*/
EFS_ADAPTER_API EFS_BOOL archiveWriteOnce(ArchiveWriterHandle handle, const char* suffix, const char* buffer, const uint32_t length, char* filename );

/**
 * 删除ArchiveWriter
 * @param  handle                 	ArchiveWriter句柄
 * @return 1          				成功
 * 		   0		   				 失败
 */
EFS_ADAPTER_API EFS_BOOL archiveReleaseWriter(ArchiveWriterHandle handle);

/**
 * 释放小文件打包后台资源
 * @describe  释放小文件打包后台的资源
 * @limit 再退出进程之前，需要主动调用，以释放后台资源
 */
EFS_ADAPTER_API void archiveManagerRelease( void );

/************************************************************************
 ** archiveReader接口定义
 ***********************************************************************/

/**
 * 创建Reader
 * @describe
 * @return ArchiveReader句柄
 * 	   	   通过isArchiveReaderHandleValid来判断是否有效
 */
EFS_ADAPTER_API ArchiveReaderHandle createArchiveReader( EFSHandle handle );

/**
 * 资源释放
 * @param  handle             ArchiveReader句柄
 * @limit 关闭大文件，小文件等类资源，要求用户显示调用efs.close之前，需要主动调用release方法
 *        同时，不对EFileSystem对象做释放操作
* @return 1成功
*		  0失败
 */
EFS_ADAPTER_API EFS_BOOL archiveReleaseReader(ArchiveReaderHandle handle);

/**
 * 打开小文件
 * @describe 打开特定后缀的小文件，为读作准备
 * @param  handle             	ArchiveReader句柄
 * @param  filename      		文件名
 * @param  length    			小文件长度
* @return 1						成功
*		  0						失败
 */
EFS_ADAPTER_API EFS_BOOL archiveReaderOpen( ArchiveReaderHandle handle, const char* filename, uint64_t* length );

/**
 * 读文件
 * @describe 读取指定长度的小文件数据
 * @param  handle             	ArchiveReader句柄
 * @param  buffer 				 读出数据buffer
 * @param  length 				 buf长度
 * @return     0				暂时不可读，待重试
 * 			   大于0				实际读出量
 * 			   -1				文件异常，需要关闭文件
 * 			   -2				读到文件尾
 * 			   失败原因通过getLastError()获取
 */
EFS_ADAPTER_API int32_t archiveRead( ArchiveReaderHandle handle, char* buffer, const uint32_t length );

/**
 * 关闭正在读的小文件
 * @param  handle             	ArchiveReader句柄
 * @describe 关闭正在读的小文件
 * @return 1						成功
 *		  0						失败
 */
EFS_ADAPTER_API EFS_BOOL archiveReaderClose(ArchiveReaderHandle handle);

/**
 * 一次性读取文件
 * @describe 集成open read close，内部保证原子性
 * @param handle: ArchiveReader句柄
 * @param filename: 文件名
 * @param buffer: 读出数据buffer
 * @param length: buf长度
 * @param timeout: 读取的超时时间,单位毫秒
 			-1，表示直到读取成功才返回
 			大于等于0，表示超过该时间未读取成功，则返回
 */
EFS_ADAPTER_API EFS_BOOL archiveReadOnce(ArchiveReaderHandle handle, const char* filename, char* buffer, const uint32_t length, int32_t timeout);

/**
 * 解析文件名
 * @describe 通过打包文件名，提取域名、存储文件名以及数据大小
 * @param  archname        	打包文件名
 * @param  regionname  		子域名
 * @param  filename    		文件名
 * @param  size        		数据大小
 * @return 1				成功
 *		   0				失败
 */
EFS_ADAPTER_API EFS_BOOL archiveGetInfos( const char* archname, char* regionname, char *filename, uint64_t& size );


#ifdef __cplusplus
}
#endif

#endif    //__INCLUDE_DAHUA_ARCHIVEADAPTER_H__
