//
//  "$Id$"
//
//  Copyright ( c )1992-2013, ZheJiang Dahua Technology Stock CO.LTD.
//  All Rights Reserved.
//
//    Description:
//    Revisions:        Year-Month-Day  SVN-Author  Modification
//

#ifndef __INCLUDE_DAHUA_EFS_ADAPTER_H__
#define __INCLUDE_DAHUA_EFS_ADAPTER_H__


#include "IntTypes.h"

// WIN32 Dynamic Link Library
#ifdef _MSC_VER

#ifdef EFS_ADAPTER_DLL_BUILD
#define  EFS_ADAPTER_API _declspec(dllexport)
#elif defined EFS_ADAPTER_DLL_USE
#define  EFS_ADAPTER_API _declspec(dllimport)
#else
#define EFS_ADAPTER_API
#endif

#else

#define EFS_ADAPTER_API

#endif

#ifdef __cplusplus
extern "C" {
#endif

/************************************************************************
 ** 常量定义
 ***********************************************************************/
#ifndef EFS_BOOL
#define EFS_BOOL    int32_t
#endif

#ifndef EFS_TRUE
#define EFS_TRUE    1
#endif

#ifndef EFS_FALSE
#define EFS_FALSE   0
#endif

// 名称长度常量
#define MAX_BUCKET_NAME_LEN 64
#define MAX_FILE_NAME_LEN   256
#define MAX_FILE_PATH_LEN   256

/************************************************************************
 ** 枚举定义
 ***********************************************************************/

//文件读写模式
typedef enum __EFSFileMode
{
    fileModeRead = 1,                   ///<读
    fileModeWrite,                      ///<写
	fileModeAppend						///<大文件追加写
}EFSFileMode;

//文件指针位置
typedef enum __EFSFileLocation
{
    efsBegin,                           ///<开始位置
    efsCurrent,                         ///<当前位置
    efsEnd                              ///<文件尾
}EFSFileLocation;

typedef enum __EFSOption
{
    efsConcurrent,                      ///<并发数
    efsBufferSize,                      ///<缓存大小，以字节为单位
    efsTimeOut,                         ///<超时时间，以毫秒为单位
    efsLogOutput,                       ///<日志文件输出路径
    efsLogLevel,                        ///<日志级别
    efsRwMode,                          ///<读写模式(0异步1同步)
    efsSmallFileBufferSize,             ///<小文件缓存大小， EFSFileHandle的setOption调用影响后续的小文件buffer
	efsBufferMode                       ///<读缓存模式(1默认单缓存2双缓存用于提高频繁seek场景下的读性能)
}EFSOption;

typedef enum __AccessPrivilege {
	privilegePrivate	= 0,			///<私有，其他用户不可见
	privilegeRead		= 1,			///<只读，其他用户无创建、删除、写入权限
	privilegeWrite		= 2				///<读写，其他用户有创建、删除、写入权限
}AccessPrivilege;

//bucket循环覆盖操作类型
typedef enum __RecycleAction{
    doDelete = 0                        ///<删除
}RecycleAction;

//使用空间达到阈值时的回收策略
typedef enum __RecyclePolicy{
    reduceByTime = 0,                   ///<等时间缩减
    reduceByRatio = 1,                  ///<等比例缩减
}RecyclePolicy;

//日志级别
enum
{
    FATALF=1,
    ERRORF,
    WARNF,
    INFOF,
    TRACEF,
    DEBUGF
};

//文件状态
typedef enum __EFSFileState
{
	fileStateInit,						///初始状态
	fileStateNormal,					///<文件正常
	fileStateWarning,					///<文件有风险
	fileStateException					///<文件异常
}EFSFileState;

//EFS状态
typedef enum __EFSState {
	efsStateInit,						///初始状态
	efsStateNormal,						///<efs客户端正常
	efsStateException,					///<efs客户端异常，会进行自动恢复
	efsStateError                      ///<efs客户端异常，可能是用户不存在或者密码错误，不可自动恢复，需要用户介入. 
}EFSState;

/************************************************************************
 ** 结构体定义
 ***********************************************************************/
//EFS实例句柄
typedef struct EFSHandle{
    uint64_t handle;
}EFSHandle;

//EFS File实例句柄
typedef struct EFSFileHandle{
    uint64_t handle;
}EFSFileHandle;

//EFS Bucket实例句柄
typedef struct EFSBucketHandle{
    uint64_t handle;
}EFSBucketHandle;

//EFS Token 实例句柄
typedef struct EFSTokenHandle{
    uint64_t handle;
}EFSTokenHandle;


//初始化配置信息
typedef struct __EFSConfig
{
    const char* address;                ///<元数据IP地址
    uint32_t    port;                   ///<端口
    const char* userName;               ///<登录名
    const char* password;               ///<登录密码
	char		reserved[120];			///<保留
}EFSConfig;

//系统信息
typedef struct __EFSSystemInfo
{
    uint32_t    totalNodes;             ///<总共集群节点数
    uint32_t    totalClient;            ///<当前运行的总客户端数
    uint32_t    curWriteFiles;          ///<当前正在写的文件数
    uint64_t    totalFiles;             ///<该用户总存储文件数
    uint64_t    totalSpace;             ///<该用户总存储空间量，单位MB
    uint64_t	spaceLeft;				///<剩余存储空间量，表示系统真实可写剩余量，单位MB
	char        uuid[32];               ///<系统uuid,32个字符
	uint64_t    spaceQuotaLeft;         ///<剩余可分配配额，单位MB
	uint64_t    spaceUsed;              ///<用户已使用容量, 单位MB
    char		reserved[44];			///<保留
}EFSSystemInfo;

//文件属性
typedef struct __EFSFileStat
{
    uint8_t     mode;         		    ///<读写模式
    uint8_t     isAppend;               ///<是否正在被写入 1是 0否
    uint8_t     dataNum;                ///<数据块个数N
    uint8_t     parityNum;              ///<冗余块个数M
    uint32_t    cTime;                  ///<创建时间
    uint32_t    mTime;                  ///<最后修改时间
    uint64_t    totalSize;              ///<文件大小，以字节为单位
    char        reserved2[108];         ///<保留
}EFSFileStat;

//文件n+m冗余模式，表示dataNum个数据块计算得到parityNum个冗余块，实现数据冗余
typedef struct __EFSRedundanceCap
{
	uint16_t dataNum;	///<数据块个数n
	uint16_t parityNum;	///<冗余块个数m
}EFSRedundanceCap;

typedef struct __EFSFileInfo
{
	char name[MAX_FILE_NAME_LEN];      ///<文件名
	uint64_t size;                       ///<大小，字节为单位
	uint32_t cTime;                      ///<创建时间，格林威治时间秒数
	uint32_t mTime;                      ///<修改时间，格林威治时间秒数
	char     reserved[48];               ///<保留
}EFSFileInfo;

//文件状态回调函数类型
typedef void (*fileStateCallBack)(EFSFileHandle, EFSFileState);

//EFS状态回调类型
typedef void (*efsStateCallBack)(EFSHandle, EFSState);

/************************************************************************
 ** 接口定义
 ***********************************************************************/
 
/**
 * 判断文件系统是否合法
 * @param  handle 文件系统句柄
 * @return 1      文件系统句柄合法
 *         0      文件系统句柄无效
 */
 EFS_ADAPTER_API EFS_BOOL isEFSHandleValid(EFSHandle handle);

/**
 * 判断文件是否合法
 * @param  handle 文件句柄
 * @return 1      文件句柄合法
 *         0      文件句柄无效
 */
EFS_ADAPTER_API EFS_BOOL isEFSFileHandleValid(EFSFileHandle handle);

/**
 * 判断bucket是否合法
 * @param  handle bucket句柄
 * @return 1      bucket句柄合法
 *         0      bucket句柄无效
 */
EFS_ADAPTER_API EFS_BOOL isEFSBucketHandleValid(EFSBucketHandle handle);

/**
 * 获取错误码
 * @return 错误码，可以通过efsGetErrorMsg()查看错误原因
 */
EFS_ADAPTER_API int32_t efsGetLastError();

/**
 * 根据错误码获取错误原因
 * @param  code    错误码
 * @return 字符串  错误原因
 */
EFS_ADAPTER_API const char* efsGetErrorMsg( int32_t code );

/**
 * 初始化文件系统
 * @param  cfg                 配置文件
 * @return EFSHandler          文件系统句柄
 *         通过isEFSHandleValid来判断句柄是否有效, 失败原因通过efsGetLastError()获取
 *         可能的error code有：
 *         efsOK               成功
 *         efsNetError         网络异常
 *         efsUserInexistent   用户不存在
 *         efsErrorPassword    密码错误
 *         efsMaxClientLimit   达到最大客户端数量
 *         efsParamError       参数错误
 */
EFS_ADAPTER_API EFSHandle efsCreate( EFSConfig* cfg );

/**
 * 设置系统高级配置
 * @param  handle             文件系统句柄
 * @param  key                配置项，
 *         配置项的可选值为：
 * 				 efsConcurrent  文件并发数
 *				 efsBufferSize  文件默认缓存大小
 *				 efsTimeOut     调用超时时间
 *				 efsLogOutput	日志输出路径
 *				 efsLogLevel    日志级别(1:fatal 2:error 3:warn 4:info 5:tarce 6:debug)
 *				 efsRwMode      读写模式(0异步1同步)
 *				 efsSmallFileBufferSize   小文件缓存大小
 *				 efsBufferMode  读缓存模式(1默认单缓存2双缓存用于提高频繁seek场景下的读性能)
 * @param  value              配置项key对应的值
 * @param  len                value长度，以字节为单位
 * @return 1                  成功
 *         0                  失败，失败原因通过getLastError()获取
 *         可能的error code有：
 *         efsOK              成功
 *         efsParamError      参数错误
 *         efsUnsupported     不支持
 */
EFS_ADAPTER_API EFS_BOOL efsSetOption( EFSHandle handle, EFSOption key, const void* value, uint32_t len);

/**
 * 获取系统高级配置
 * @param  handle             文件系统句柄
 * @param  key                配置项
           配置项的可选值为：
 * 		 		 efsConcurrent  文件并发数
 *				 efsBufferSize  文件默认缓存大小
 *				 efsTimeOut     调用超时时间
 *				 efsLogOutput	日志输出路径
 *				 efsLogLevel    日志级别(1:fatal 2:error 3:warn 4:info 5:tarce 6:debug)
 *				 efsRwMode      读写模式(0异步1同步)
 *				 efsSmallFileBufferSize   小文件缓存大小
 *				 efsBufferMode  读缓存模式(1默认单缓存2双缓存用于提高频繁seek场景下的读性能)
 * @param  value              配置项key对应的值
 * @param  len                value长度，以字节为单位
 * @return 1                  成功
 *         0                  失败，失败原因通过getLastError()获取
 *         可能的error code有：
 *         efsOK              成功
 *         efsParamError      参数错误
 *         efsUnsupported     不支持
 */
EFS_ADAPTER_API EFS_BOOL efsGetOption( EFSHandle handle, EFSOption key, void* value, uint32_t len);

/**
 * 获取该用户相关系统信息
 * @param  handle 文件系统句柄
 * @param  info   系统信息结构体
 * @return 1      成功
 *         0      失败，失败原因通过getLastError()获取
 */
EFS_ADAPTER_API EFS_BOOL efsGetSystemInfo( EFSHandle handle, EFSSystemInfo* info );

/**
 * 获取文件系统系统支持的冗余类型
 * @param  handle  文件系统句柄
 * @param  caps    存放冗余组合的数组
 * @param  size    caps数组的大小
 * @return -1      失败,失败原因通过getLastError()获取
 *         -2      失败，caps数组长度不足以存放冗余类型
 *         >=0     支持的冗余类型个数
 */
EFS_ADAPTER_API int32_t efsGetRedundanceCaps( EFSHandle handle , EFSRedundanceCap* caps, uint32_t size );

/**
 * 获取EFSTokenHandle查询令牌
 * @return token句柄  
 */
EFS_ADAPTER_API EFSTokenHandle efsGetToken( );

/**
 * 获取bucket列表
 * @param  handle             文件系统句柄
 * @param  token              查询令牌，需用户自定义
 * @param  maxNumber          最大数量
 * @param  buffer             返回的bucket名列表
 * @return 1                  成功
 *         0                  失败，失败原因通过getLastError()获取
 */
EFS_ADAPTER_API int32_t efsListBucket( EFSHandle handle, EFSTokenHandle token, uint32_t maxNumber, char buffer[][MAX_BUCKET_NAME_LEN] );

/**
 * 释放EFSTokenHandle查询令牌
 * @param  handle  文件系统句柄
 * @return 1       释放成功
           0       释放失败 
 */
EFS_ADAPTER_API EFS_BOOL efsReleaseToken( EFSTokenHandle token );

/**
 * 关闭文件系统并释放句柄
 * @param  handle             文件系统句柄
 * @return 1                  成功
 *         0                  失败，失败原因通过getLastError()获取
 */
EFS_ADAPTER_API EFS_BOOL efsClose( EFSHandle handle );

/**
 * 创建文件
 * @param  handle           文件系统句柄
 * @param  fileName         文件名, 包含所在Bucket的名字, 以/分割
 *                          不允许以下字符\, *, ?, ", <, >, |
 *                          最大长度不超过MAX_BUCKET_FILE_NAME_LEN（1024）
 * @param  n                冗余规则(n+m)中的n，即有效数据个数
 * @param  m                冗余规则(n+m)中的m，即有效数据的校验个数
 * @param  bigFile          是否大文件
 * @return EFSFileHandle    文件实例句柄，通过调用isEFSFileHandleValid()来判断创建是否成功
 *                          若失败，通过getLastError()获取失败原因
 */
EFS_ADAPTER_API EFSFileHandle efsCreateFile( EFSHandle handle, const char* fileName, uint16_t n, uint16_t m, EFS_BOOL bigFile );

/**
 * 删除文件
 * @param  handle             文件系统句柄
 * @param  fileName           文件名
 * @return 1                  成功
 *         0                  失败，失败原因通过getLastError()获取
 *         可能的error code有：
 *         efsOK              成功
 *         efsFail            失败
 *         efsParamError      参数错误
 */
EFS_ADAPTER_API EFS_BOOL efsRemoveFile( EFSHandle handle, const char* fileName );

/**
 * 重命名文件，只对Bucket内文件有效
 * @param  handle              文件系统句柄
 * @param  oldName             原文件名
 * @param  newName             新文件名，最大长度不超过MAX_BUCKET_FILE_NAME_LEN（1024）
 * @return 1                   成功
 *         0                   失败，失败原因通过getLastError()获取
 *         可能的error code有：
 *         efsOK               成功
 *         efsFail             失败
 *         efsParamError       参数错误
 */
EFS_ADAPTER_API EFS_BOOL efsRenameFile( EFSHandle handle, const char* oldFileName, const char* newFileName );

/**
 * 打开文件
 * @param  handle           文件系统句柄
 * @param  fileName         文件名
 * @param  mode             文件模式，可选值为：
 *         fileModeRead     读模式
 *         fileModeWrite    写模式（暂不支持）
 * @return EFSFileHandle    文件实例句柄，通过调用isEFSFileHandleValid()来判断创建是否成功
 *                          若失败，通过getLastError()获取失败原因
 */
EFS_ADAPTER_API EFSFileHandle efsOpenFile( EFSHandle handle, const char* fileName, EFSFileMode mode );

/**
 * 获取文件名
 * @param  handle 文件句柄
 * @param  name   存放文件名的buffer
 * @param  len    buffer长度
 * @return 1      成功
 *         0      返回失败
 */
EFS_ADAPTER_API EFS_BOOL efsGetFileName( EFSFileHandle handle, char* name, uint32_t len );

/**
 * 写文件
 * @param  handle 文件句柄
 * @param  buf    待写入数据
 * @param  len    数据长度
 * @return 0      暂时不可写，待重试
 *         >0     实际写入量
 *         -1     写入失败，需要关闭文件
 */
EFS_ADAPTER_API int32_t efsWrite( EFSFileHandle handle, const char* buf, uint32_t len );

/**
 * 读文件
 * @param  handle 文件句柄
 * @param  buf    读出数据buffer
 * @param  len    buf长度
 * @return 0      暂时不可读，待重试
 *         >0     实际读出量
 *         -1     文件异常，需要关闭文件
 *         -2     已经读到文件末尾
 */
EFS_ADAPTER_API int32_t efsRead( EFSFileHandle handle, char* buf, uint32_t len );

/**
 * 文件定位
 * @param  handle          文件句柄
 * @param  offset          相对于whence的偏移
 * @param  whence          seek类型
           whence可选值为：
 *         efsBegin        文件头
 *         efsCurrent      当前文件位置
 *         efsEnd          文件尾
 * @return 1               成功
 *         0               失败，失败原因通过getLastError()获取
 *         可能的error code有：
 *         efsOK           成功
 *         efsFail         失败
 *         efsInvalidFile  文件无效
 */
EFS_ADAPTER_API EFS_BOOL efsSeek( EFSFileHandle handle, int64_t offset, EFSFileLocation whence );

/**
 * 获取文件位置
 * @param  handle  文件句柄
 * @return 大于等于0    文件当前相对于头的偏移位置
 *         小于0        获取失败
 */
EFS_ADAPTER_API int64_t efsTell( EFSFileHandle handle );

/**
 * 获取文件属性
 * @param  handle  文件句柄
 * @param  stat    存放文件属性
 * @return 1       成功
 *         0       失败，失败原因通过getLastError()获取
 */
EFS_ADAPTER_API EFS_BOOL efsGetFileStat( EFSFileHandle handle, EFSFileStat* stat ) ;

/**
 * 关闭文件并释放文件句柄
 * @param  handle  文件句柄
 * @return 1       成功
 *         0       失败，失败原因通过getLastError()获取
 */
EFS_ADAPTER_API EFS_BOOL efsCloseFile( EFSFileHandle handle );


/**
 * 设置文件选项
 * @param  handle  file句柄
 * @param  key     配置项，
 *         配置项的可选值为：
 * 				 efsConcurrent  文件并发数
 *				 efsBufferSize  文件默认缓存大小
 *				 efsTimeOut     调用超时时间
 *				 efsLogOutput	日志输出路径
 *				 efsLogLevel    日志级别(1:fatal 2:error 3:warn 4:info 5:tarce 6:debug)
 *				 efsRwMode      读写模式(0异步1同步)
 *				 efsSmallFileBufferSize   小文件缓存大小
 *				 efsBufferMode  读缓存模式(1默认单缓存2双缓存用于提高频繁seek场景下的读性能)
 * @param  value              配置项key对应的值
 * @param  len                value长度，以字节为单位
 * @return 1                  成功
 *         0                  失败，失败原因通过getLastError()获取
 *         可能的error code有：
 *         efsOK              成功
 *         efsParamError      参数错误
 *         efsUnsupported     不支持
 */
EFS_ADAPTER_API EFS_BOOL efsSetFileOption(EFSFileHandle handle, EFSOption key, const void* value, uint32_t len);

/**
 * 获取文件选项
 * @param  handle  file句柄
 * @param  key     配置项，
 *         配置项的可选值为：
 * 				 efsConcurrent  文件并发数
 *				 efsBufferSize  文件默认缓存大小
 *				 efsTimeOut     调用超时时间
 *				 efsLogOutput	日志输出路径
 *				 efsLogLevel    日志级别(1:fatal 2:error 3:warn 4:info 5:tarce 6:debug)
 *				 efsRwMode      读写模式(0异步1同步)
 *				 efsSmallFileBufferSize   小文件缓存大小
 *				 efsBufferMode  读缓存模式(1默认单缓存2双缓存用于提高频繁seek场景下的读性能)
 * @param  value              配置项key对应的值
 * @param  len                value长度，以字节为单位
 * @return 1                  成功
 *         0                  失败，失败原因通过getLastError()获取
 *         可能的error code有：
 *         efsOK              成功
 *         efsParamError      参数错误
 *         efsUnsupported     不支持
 */
EFS_ADAPTER_API EFS_BOOL efsGetFileOption(EFSFileHandle handle, EFSOption key, void* value, uint32_t len);

/** 
 * 创建一个bucket
 * @param  handle               文件系统句柄
 * @param  name                 Bucket名字，最大长度不超过MAX_BUCKET_NAME_LEN（63）
 *                              不允许以下字符\, *, ?, ", <, >, |
 * @return EFSBucketHandle      bucket实例句柄，通过调用isEFSBucketHandleValid()来判断创建是否成功
 *                              若失败，通过getLastError()获取失败原因
 */
EFS_ADAPTER_API EFSBucketHandle efsCreateBucket( EFSHandle handle, const char* name );

/**
 * 删除一个bucket
 * @param  handle             文件系统句柄
 * @param  name bucket        Bucket名字
 * @return 1                  成功
 *         0                  失败，失败原因通过getLastError()获取
 *         可能的error code有：
 *         efsOK              成功
 *         efsFail            失败
 *         efsParamError      参数错误
 */
EFS_ADAPTER_API EFS_BOOL efsRemoveBucket( EFSHandle handle, const char* name );

/**
 * 获取一个bucket
 * @param  handle               文件系统句柄
 * @param  name                 bucket名字
 * @return EFSBucketHandle      bucket实例句柄，通过调用isEFSBucketHandleValid()来判断创建是否成功
 *                              若失败，通过getLastError()获取失败原因
 */
EFS_ADAPTER_API EFSBucketHandle efsGetBucket( EFSHandle handle, const char* name );

/**
 * 获取bucket名
 * @param  handle  bucket句柄
 * @param  buf     接收缓冲区
 * @param  len     buf长度，以字节为单位
 * @return 1       成功
 *         0       失败
 */
EFS_ADAPTER_API EFS_BOOL efsGetBucketName( EFSBucketHandle handle, char* buf, uint32_t len );

/**
 * 设置bucket最大容量
 * @param  handle    bucket句柄
 * @param  megaBytes 容量值，以MB计
 * @return 1         成功
 *         0         失败，失败原因通过getLastError()获取
 */
EFS_ADAPTER_API EFS_BOOL efsSetBucketCapacity( EFSBucketHandle handle, uint64_t megaBytes );

/**
 * 获取bucket最大容量和已使用容量
 * @param  handle              bucket句柄
 * @param  [out] megaBytes     容量值，以MB计
 * @param  [out] usedMegaBytes 已使用容量值，以MB计
 * @return 1                   成功
 *         0                   失败，失败原因通过getLastError()获取
 */
EFS_ADAPTER_API EFS_BOOL efsGetBucketCapacity( EFSBucketHandle handle,  uint64_t* megaBytes, uint64_t* usedMegaBytes );

/**
 * 获取bucket权限
 * @param	[out]privilege	访问权限的指针
 * @return	1				成功
 * 			0				失败，失败原因通过getLastError()获取
 */
EFS_ADAPTER_API EFS_BOOL efsGetBucketPrivilege( EFSBucketHandle handle, AccessPrivilege* privilege );

/**
 * 设置bucket权限
 * @param	[in]privilege	访问权限，枚举值
 * @return	1				成功
 * 			0				失败，失败原因通过getLastError()获取
 */
EFS_ADAPTER_API EFS_BOOL efsSetBucketPrivilege( EFSBucketHandle handle, AccessPrivilege privilege );

/**
 * 锁定文件
 * @param  handle              文件系统句柄
 * @param  fileName            文件名
 * @return  1                  成功
 *          0                  失败，失败原因通过getLastError()获取
 */
EFS_ADAPTER_API EFS_BOOL efsLockFile(EFSHandle handle, const char* fileName);

/**
 * 获取文件锁定状态
 * @param   fileName 文件名,包含bucket名
 * @return  1 锁定
 *          0 未锁定
 *          -1 获取失败，失败原因通过getLastError()获取
 */
EFS_ADAPTER_API int32_t efsGetFileLockStat(EFSHandle handle, const char* fileName);

/**
 * 解锁文件
 * @param  handle              文件系统句柄
 * @param  fileName            文件名
 * @return  1                  成功
 *          0                  失败，失败原因通过getLastError()获取
 */
EFS_ADAPTER_API EFS_BOOL efsUnlockFile(EFSHandle handle, const char* fileName);

/**
 * 设置用户空间回收策略,仅对已使能生命周期的bucket有效
 * @param   handle        文件系统句柄
 * @param   enableRecycle 是否使能用户空间回收
 * @param   policy: reduceByTime  等时间缩减
                    reduceByRatio 等比例缩减
 * @return  1 成功
            0 失败，失败原因通过getLastError()获取
 */
EFS_ADAPTER_API EFS_BOOL efsSetRecyclePolicy(EFSHandle handle,  EFS_BOOL enableRecycle , RecyclePolicy policy);

/**
 * 获取用户空间回收策略配置
 * @param   handle       文件系统句柄
 * @param   enableRecycle 是否使能用户空间回收
 * @param   policy: reduceByTime  等时间缩减
                    reduceByRatio 等比例缩减
 * @return  1 成功
            0 失败，失败原因通过getLastError()获取
 */
EFS_ADAPTER_API EFS_BOOL efsGetRecyclePolicy(EFSHandle handle,  EFS_BOOL* enableRecycle , RecyclePolicy* policy);

/**
 * 设置bucket生命周期
 * bucket中的文件过期时，执行参数RecycleAction act所指定的操作
 * 过期条件:当前时间 - 文件创建时间 >= 参数 delay
 * @param   handle  bucket句柄
 * @param   delay bucket过期时间，单位为秒，最小值为1小时即3600秒
 * @param   enableAction 是否使能参数act所指定的操作，该值为false时，设置的delay会不生效
 * @param   removeWhenBucketEmpty 当bucket为空时，是否删除
 * @param   act bucket过期时执行的操作，暂仅支持删除操作
 * @param   prefix 保留字段
 * @return  1 设置成功
            0 设置失败，失败原因通过getLastError()获取
 */
EFS_ADAPTER_API EFS_BOOL efsSetBucketLifeCycle(EFSBucketHandle handle, int64_t delay, EFS_BOOL enableAction,
                            EFS_BOOL removeWhenBucketEmpty, RecycleAction act, const char* prefix);

/**
 * 获取bucket生命周期配置
 * @param   handle  bucket句柄
 * @param   delay bucket过期时间，单位为秒
 * @param   enableAction 是否使能act所指定的操作
 * @param   removeWhenBucketEmpty 当bucket为空时，是否删除
 * @param   act bucket过期时执行的操作，暂仅支持删除操作
 * @param   prefix 保留字段
 * @return  1 获取成功
            0 获取失败，失败原因通过getLastError()获取
 */
EFS_ADAPTER_API EFS_BOOL efsGetBucketLifeCycle(EFSBucketHandle handle, int64_t* delay, EFS_BOOL* enableAction,
                            EFS_BOOL* removeWhenBucketEmpty, RecycleAction* act, const char* prefix);

/**
 * 列出bucket内文件名落在[begin,end]范围的文件名列表
 * @param  handle    bucket句柄
 * @param  begin     起始文件名，不包含bucket名
 * @param  end       终止文件名，不包含bucket名
 * @param  maxNumber 最大数量
 * @param  buffer    输出文件名列
 * @return >=0       获取到的文件名个数
 *         -1        获取失败原因通过getLastError()获取
 */
EFS_ADAPTER_API int32_t efslistBucketFile( EFSBucketHandle handle, const char* begin, const char* end, uint32_t maxNumber, char buffer[][MAX_FILE_NAME_LEN] );

/**
 * 获取bucket内的文件信息
 * @param  handle    bucket句柄
 * @param  begin     文件名开始匹配的字符串
 * @param  end       文件名结束匹配的字符串
 * @param  maxNumber 获取的最大个数
 * @param  pinfo     存放文件信息的数组指针，缓存个数必须保证大于等于maxNumber
 * @return >=0       获取到的文件信息的个数  
 *         <0        获取失败
 */
EFS_ADAPTER_API int32_t efsListBucketFileInfo( EFSBucketHandle handle, const char* begin, const char* end, uint32_t maxNumber, EFSFileInfo* pinfo );


/**
 * 列出bucket内文件名为dir前缀，以delimiter为后缀的文件名列表
 * @param prefix 文件名前缀，例如 a/b/
 * @param delimiter 后缀，目前只能是 ‘/’
 * @param maxNumber 最大数量，例如10
 * @param list 输出文件名列，例如存在a/b/c a/b/d/ a/b/d/e,得到的结果为‘a/b/c’和‘a/b/d/’
 * @return >=0       获取到的文件信息的个数  
 *         <0        获取失败
 */
EFS_ADAPTER_API int32_t efsListBucketFileInfoByPrefix( EFSBucketHandle handle, const char* dir, const char* delimiter, const char* begin, uint32_t maxNumber, EFSFileInfo* pinfo );

/**
 * 获取Bucket下的文件数
 * @param handle Bucket操作句柄
 * @param bigFileNum 大文件数
 * @param smallFileNum 小文件数
 * @return EFS_TRUE成功，EFS_FALSE失败
 */
EFS_ADAPTER_API EFS_BOOL efsGetBucketFileNum( EFSBucketHandle handle, uint64_t* bigFileNum, uint64_t* smallFileNum );

/**
 * 释放bucket句柄
 * @param  handle  bucket句柄
 * @return 1       释放成功
 *         0       释放失败
 */
EFS_ADAPTER_API EFS_BOOL efsCloseBucket( EFSBucketHandle handle );

/**
 * 设置EFS状态回调
 * @param  handle  EFS句柄
 * @param  cb      EFS状态回调函数
 * @return 1       设置成功
 *         0       设置失败
 */
EFS_ADAPTER_API EFS_BOOL efsSetStateCallBack(EFSHandle handle, efsStateCallBack cb);

/**
 * 设置文件状态回调
 * @param  handle  file句柄
 * @param  cb      文件状态回调函数
 * @return 1       设置成功
 *         0       设置失败
 */
EFS_ADAPTER_API EFS_BOOL efsSetFileStateCallBack(EFSFileHandle handle, fileStateCallBack cb);

/**
 * 设置文件用户属性
 * @param  handle      file句柄
 * @param  attribute   attribute为用户输入的自定义属性，length为缓冲区长度，不允许超过32字节。
 * @param  length      attribute长度，规定为32字节以字节为单位，用户需要保证attribute与length的对应关系。
 * @return 1 成功
 * 		   0 失败，失败原因通过getLastError()获取
*/
EFS_ADAPTER_API EFS_BOOL efsSetFileAttribute(EFSFileHandle handle, const char *attribute, uint32_t length);

/**
 * 获取文件用户属性
 * @param  handle      file句柄
 * @param  attribute   attribute为用户输入的自定义属性，length为缓冲区长度，不允许超过32字节。
 * @param  length      attribute长度，规定为32字节以字节为单位
 * @return 大于等于0实际获取到的自定义属性长度
 * 		   小于0失败，失败原因通过getLastError()获取
*/
EFS_ADAPTER_API int32_t efsGetFileAttribute(EFSFileHandle handle, char *attribute, uint32_t length);

#ifdef __cplusplus
}
#endif

#endif    //__INCLUDE_DAHUA_EFS_ADAPTER_H__
