
#ifndef __INCLUDE_DAHUA_EFS_INTERRUPT_HANDLER_H__
#define __INCLUDE_DAHUA_EFS_INTERRUPT_HANDLER_H__

namespace Dahua{
namespace EFS{

void dahuaBacktraceInit();

}//end of namespace EFS
}//end of name space Dahua

#endif

