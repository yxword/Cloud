//
//  "$Id: NDefs.h 17071 2010-12-08 05:48:16Z wang_haifeng $"
//
//  Copyright (c)1992-2010, ZheJiang Dahua Technology Stock CO.LTD.
//  All Rights Reserved.
//
//	Description:	
//	Revisions:		Year-Month-Day  SVN-Author  Modification
//					
//

#ifndef __INCLUDE_DAHUA_NETFRAMEWORK_NDEFS_H__
#define __INCLUDE_DAHUA_NETFRAMEWORK_NDEFS_H__

#ifdef WIN32

#ifdef NETFRAMEWORK_DLL_BUILD
#define  NETFRAMEWORK_API _declspec(dllexport)
#elif defined NETFRAMEWORK_DLL_USE
#define  NETFRAMEWORK_API _declspec(dllimport)
#else
#define NETFRAMEWORK_API  
#endif

#else
#define NETFRAMEWORK_API  
#endif

#endif  //__INCLUDED_DAHUA_NETFRAMEWORK_NET_HANDLER_H__
